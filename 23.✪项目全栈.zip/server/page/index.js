// 引入模块
var home = require('./home');
var admin = require('./admin');

// 打包在一起
module.exports = { home, admin }