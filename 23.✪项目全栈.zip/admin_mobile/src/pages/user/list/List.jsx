// 引入react
import React, { Component } from 'react';

// 定义组件
export default class List extends Component {
	// 渲染
	render() {
		return <h1>user list page</h1>
	}
}