// 引入react
import React, { Component } from 'react';

// 定义组件
export default class Edit extends Component {
	// 渲染
	render() {
		return <h1>user edit page</h1>
	}
}