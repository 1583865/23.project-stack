// 引入react
import React, { Component } from 'react';

// 定义组件
export default class Create extends Component {
	// 渲染
	render() {
		return <h1>user create page</h1>
	}
}